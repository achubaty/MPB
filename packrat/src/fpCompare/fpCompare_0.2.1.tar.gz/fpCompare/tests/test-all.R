library(testthat)
test_check("fpCompare")
