/* SpherModelsinitNerror.h */
#ifndef SPHERMODELSinitNerror_H
#define SPHERMODELSinitNerror_H 1


/* declaration of functions */

void SpherModelsinit( );

#endif /* SpherModelsinitNerror.h */
