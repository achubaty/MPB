#
# generic rmh

rmh <- function(model, ...){
     UseMethod("rmh")
}

