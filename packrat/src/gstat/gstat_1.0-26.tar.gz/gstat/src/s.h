void s_gstat_error(const char *mess, int level);
void s_gstat_warning(const char *mess);
