test_that("check all examples", {
  test_examples(path = "../../man")
})
